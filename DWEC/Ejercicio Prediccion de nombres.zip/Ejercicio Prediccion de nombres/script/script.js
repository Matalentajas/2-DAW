// Boton
let boton_nombre = document.getElementById("boton_nombre")
// Fin boton
//Inputs HTML
const edad_box = document.getElementById("edad_box")
const sexo_box = document.getElementById("sexo_box")
const nacionalidad_box = document.getElementById("nacionalidad_box")
// Fin Inputs HTML


let GetData = async() =>{

    let edad = await axios.get(edad_url)
    let genero = await axios.get(genero_url)
    let nacionalidad = await axios.get(nacionalidad_url)
    console.log(edad);
    
};

let mostrarData = () => {

    edad_box.innerHTML`
    ${nombre} tiene ${edad_url} años.
    `

    genero_box.innerHTML`
    ${nombre} es ${genero_url}.
    `

    nacionalidad_box.innerHTML`
    ${nombre} es de ${nacionalidad_url}.
    `
}

boton_nombre.addEventListener("click", () => {

    let nombre = document.getElementById("nombre")

    edad_url = "https://api.agify.io?name=arturo"
    genero_url = "https://api.genderize.io?name=arturo"
    nacionalidad_url= "https://api.nationalize.io?name=arturo"

    GetData()

})